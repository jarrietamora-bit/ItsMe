BT-Support — Sistema de Tickets de Soporte
===========================================
Versión 1.0 | Better Technologies (bettertechcr.com)

CONTENIDO DE ESTE PAQUETE
--------------------------
bt-support/          Código fuente completo de la aplicación
documentacion/       Manuales en PDF:
  manual-instalacion.pdf  Instalación en cPanel (paso a paso)
  manual-admin.pdf        Manual del Administrador
  manual-supervisor.pdf   Manual del Supervisor
  manual-agente.pdf       Manual del Agente
  manual-cliente.pdf      Manual del Cliente / Usuario Final

INICIO RÁPIDO
-------------
1. Sube la carpeta bt-support/ a public_html/ de tu cPanel
2. Crea una base de datos MySQL en cPanel
3. Abre https://tu-dominio.com/bt-support/install/ y sigue los 5 pasos
4. Elimina la carpeta install/ después de instalar
5. Lee el manual-instalacion.pdf para detalles completos

NOTA PARA DESARROLLADORES
--------------------------
El archivo bt-support/CLAUDE.md contiene la guía completa del proyecto
para usar con Claude AI (arquitectura, BD, roles, patrones de código).

SOPORTE
-------
Documentación: ver carpeta docs/ dentro del código fuente
Sitio: bettertechcr.com
