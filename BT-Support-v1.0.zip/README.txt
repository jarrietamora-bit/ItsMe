BT-Support v1.0 — Better Technologies
======================================

CONTENIDO DEL PAQUETE
----------------------
bt-support/          → Código fuente del sistema (suba a public_html/)
documentacion/       → Manuales en PDF

INSTALACIÓN RÁPIDA
------------------
1. Suba la carpeta bt-support/ a su servidor (cPanel → public_html/)
2. Cree una base de datos MySQL en cPanel
3. Abra https://sudominio.com/bt-support/install/
4. Siga el asistente de instalación (5 pasos)
5. Elimine la carpeta install/ por seguridad

MANUALES INCLUIDOS
------------------
- Manual de Instalación.pdf    → Para el técnico que instala el sistema
- Manual del Administrador.pdf → Gestión completa del sistema
- Manual del Supervisor.pdf    → Gestión de departamento y equipo
- Manual del Agente.pdf        → Atención de tickets
- Manual del Cliente.pdf       → Uso del portal de soporte

REQUISITOS DEL SERVIDOR
-----------------------
- PHP 7.4+ (recomendado 8.1+)
- MySQL 5.7+ / MariaDB 10.3+
- Extensiones: PDO, OpenSSL, Fileinfo, mbstring
- Apache con mod_rewrite

SOPORTE
-------
Better Technologies — bettertechcr.com
